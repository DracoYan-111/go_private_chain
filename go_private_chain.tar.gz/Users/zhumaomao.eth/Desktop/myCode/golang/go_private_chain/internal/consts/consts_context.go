package consts

const (
	ContextKey = "ContextKey"
)
