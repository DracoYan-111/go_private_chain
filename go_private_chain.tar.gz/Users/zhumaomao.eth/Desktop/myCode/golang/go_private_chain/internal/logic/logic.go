package logic

import (
	_ "go_private_chain/internal/logic/bizctx"
	_ "go_private_chain/internal/logic/go_test_db"
	_ "go_private_chain/internal/logic/middleware"
	_ "go_private_chain/internal/logic/user_data"
)
